﻿# Plaza Vea · Demo SOA basada en AV_03

Solución completa basada en el documento **“Arquitectura Orientada al Servicio_AV_03”**. La app cubre el flujo de compra online con retiro en tienda: catálogo, existencias por tienda, confirmación de pedido, preparación en tienda, seguimiento y reportes operativos.

## Estructura del repositorio

```
plaza_vea_soa_project/
├── backend/                 # API Express modularizada en servicios
│   ├── data/                # Archivos JSON que actúan como storage
│   ├── scripts/reset-data.js# Script para regenerar datos demo
│   ├── seed/                # Catálogos base usados por el script
│   └── src/
│       ├── config/          # Constantes de negocio
│       ├── middleware/      # Manejo de errores, auth, validaciones
│       ├── repositories/    # Lectura/escritura de archivos y cachés
│       ├── routes/          # Interfaces REST (catalog, stores, orders…)
│       └── services/        # Lógica (pedidos, inventario, dashboard…)
└── frontend/                # UI en HTML/CSS/JS sin build step
```

## Novedades principales

- **Datos consistentes y reproducibles:** `npm run seed` regenera `products.json`, `inventory.json`, `operators.json`, `orders.json` y `events.json` a partir de `seed/baseData.js` (incluye hashing de PINs).
- **Endpoint de dashboard:** `GET /api/dashboard` agrega resumen diario (Órdenes, ingresos, tiendas, top productos y últimos pedidos) para nutrir la landing.
- **Frontend modular:** vistas separadas para Inicio, Comprar, Seguimiento y Operaciones; hero con métricas en tiempo real, paneles responsive y consola de operador con historial integrado.
- **Fall‑back inteligente:** si el backend no está disponible, el front usa datos demo y muestra advertencias sin romper el flujo.

## Cómo ejecutar

1. **Backend**
   ```bash
   cd backend
   npm install
   npm run seed   # opcional, resetea datos demo
   npm start
   ```
   El API queda disponible en `http://localhost:3000/api`.

2. **Frontend**
   Abrir `frontend/index.html` directamente en el navegador (o servirlo con cualquier static server). El archivo ya apunta al backend local.

## Credenciales de operador (demo)

| Operador | Tienda | ID | PIN |
| --- | --- | --- | --- |
| Sofía Ríos | Lima Centro | `op-lim-01` | `4321` |
| Pedro Alvarado | Miraflores | `op-mir-02` | `9876` |
| Ana Vidal | San Isidro | `op-sis-03` | `2468` |

Los permisos (`allowedStatuses`) se validan antes de permitir cambios de estado.

## Flujos cubiertos

1. **Catálogo** (RF-M01/M02/M03): búsqueda, selector de tienda, carrito reactivo con verificación de stock.
2. **Confirmación** (RF-M04/M05): formulario del cliente, generación de `clientRequestId`, reserva de inventario e historial inicial.
3. **Seguimiento** (RF-M08 + RNF-05/08): consulta por código PV con línea de tiempo completa.
4. **Operaciones en tienda** (RF-M06/M07 + RNF-07): login por PIN, picklist editable, cambios de estado controlados, historial en vivo.
5. **Dashboard ejecutivo:** métricas diarias, alertas de stock bajo y últimos pedidos para la portada.

## Endpoints destacados

| Método | Ruta | Descripción |
| --- | --- | --- |
| `GET` | `/api/health` | Ping básico del backend. |
| `GET` | `/api/dashboard` | Métricas diarias (pedidos, ingresos, tiendas, top productos). |
| `GET` | `/api/catalog?storeId=lima&q=pan` | Catálogo filtrado por tienda y texto. |
| `POST` | `/api/orders` | Crea un pedido (requiere `clientRequestId`, `storeId`, `customer`, `items`). |
| `GET` | `/api/orders/track/:code` | Seguimiento público (cliente) con historial. |
| `PUT` | `/api/orders/:id/picklist` | Actualiza cantidades recogidas (token de operador). |
| `PUT` | `/api/orders/:id/status` | Cambia estado a `in_preparation`, `ready` o `cancelled` según permisos. |
| `GET` | `/api/reports/orders/:id/timeline` | Historial completo para consola de operador. |

## Notas adicionales

- `docs/soa-blueprint.md` resume el diseño de servicios, estados y RNF.
- Si editas manualmente los archivos en `backend/data`, ejecuta `npm run seed` para volver a un estado conocido.
- El frontend detecta automáticamente cuando el backend no está disponible y muestra datos demo, pero la recomendación es mantener `npm start` activo para probar el flujo real.
