﻿# Plaza Vea · Demo SOA basada en AV_03

Este repositorio implementa la propuesta del documento **“Arquitectura Orientada al Servicio_AV_03”** para el flujo de compra online con retiro en tienda.  Se modelaron los servicios de Catálogo, Existencias, Pedidos, Preparación en tienda, Acceso/Roles y Registro de eventos, y se expusieron contratos REST que materializan los requisitos funcionales (RF-M01 … RF-M08) y no funcionales (RNF-01 … RNF-08).

## Estructura

```
plaza_vea_soa_project/
├── backend/              # API Express modularizada por servicios
│   ├── data/             # Datos semilla (productos, inventario, operadores, etc.)
│   └── src/
│       ├── config/       # Constantes de negocio
│       ├── middleware/   # Validación, manejador de errores, auth operadores
│       ├── repositories/ # Lectura/escritura en JSON + cachés
│       ├── routes/       # Interfaces REST por servicio (catalog, stores, orders…)
│       └── services/     # Lógica de dominio (pedidos, inventario, reportes…)
└── frontend/             # Interfaz unificada para cliente y operador (HTML/CSS/JS)
```

## Servicios y contratos clave

| Servicio (documento AV_03) | Tipo | Endpoints principales | Comentario |
| --- | --- | --- | --- |
| Catálogo | Entidad | `GET /api/catalog`, `GET /api/catalog/:id` | Busca productos y muestra disponibilidad por tienda (RF-M01, RF-M02).
| Existencias por tienda | Entidad | `GET /api/stores`, `GET /api/stores/:id`, `GET /api/stores/:id/products/:productId` | Fuente única del stock y base para apartar/devolver unidades.
| Confirmar pedido + Pedidos | Tarea + Entidad | `POST /api/orders`, `GET /api/orders/track/:code`, `GET /api/orders` | Orquesta validación de stock, crea pedido, expone seguimiento para cliente u operador.
| Preparación en tienda | Tarea | `PUT /api/orders/:id/picklist`, `PUT /api/orders/:id/status` | Panel operador marca picking, cambia estados y libera/reserva inventario.
| Registro / Reportes | Utilidad | `GET /api/reports/daily`, `GET /api/reports/orders/:id/timeline` | Resumen diario y bitácora por pedido.
| Acceso y roles | Utilidad | `POST /api/auth/login`, `POST /api/auth/logout` | Controla sesiones y estados permitidos (RNF-07).

## Requisitos cubiertos

- **RF-M01 / RF-M02 / RF-M03**: catálogo con búsqueda, selector de tienda y carrito reactivo.
- **RF-M04 / RF-M05**: checkout captura datos mínimos, genera `clientRequestId` y evita duplicados.
- **RF-M06 / RF-M07 / RF-M08**: panel de operador para picking y estados + tracking público.
- **RNF-01 … RNF-08**: manejo de errores visible, logs en `data/events.json`, bitácora en historial, sesiones temporales para operadores y revalidación de stock al confirmar/cancelar.

## Ejecución

1. **Backend**
   ```bash
   cd backend
   npm install
   npm start
   ```
   El API queda disponible en `http://localhost:3000/api`.

2. **Frontend**
   Abrir `frontend/index.html` en el navegador. El archivo ya apunta al backend local (`API_BASE = http://localhost:3000/api`).

## Credenciales de operador (demo)

| Operador | Tienda | ID | PIN |
| --- | --- | --- | --- |
| Sofia Rios | Lima Centro | `op-lim-01` | `4321` |
| Pedro Alvarado | Miraflores | `op-mir-02` | `9876` |
| Ana Vidal | San Isidro | `op-sis-03` | `2468` |

Los permisos (`allowedStatuses`) se encuentran en `backend/data/operators.json` y se validan antes de ejecutar cambios.

## Flujo de uso

1. Selecciona la tienda desde la barra superior y agrega productos al carrito.
2. Completa el formulario de checkout; la API reserva stock y devuelve el código PV-... para seguimiento.
3. Consulta el estado desde el módulo “Seguimiento” para visualizar el historial (RNF-05).
4. Desde “Operaciones en tienda” inicia sesión, filtra pedidos por estado, marca picking item por item y cambia estados a “listo” o “cancelado”.
5. Opcional: consume `GET /api/reports/daily?day=YYYY-MM-DD` para obtener métricas operativas.

## Endpoints útiles

| Método | Ruta | Descripción |
| --- | --- | --- |
| `GET` | `/api/health` | Verifica disponibilidad del backend.
| `GET` | `/api/catalog?storeId=lima&q=pan` | Catálogo filtrado por tienda y texto.
| `POST` | `/api/orders` | Crea pedido. Requiere `clientRequestId`, `storeId`, `customer`, `items`.
| `GET` | `/api/orders/track/PV-LIM-20251115-1478` | Historial visible para el cliente.
| `PUT` | `/api/orders/:id/picklist` | Actualiza picking (requiere token de operador).
| `GET` | `/api/reports/daily?day=2025-11-19` | Resumen diario (pedidos, ingresos, eventos).

## Documentación adicional

Se añadieron datos y utilidades alineadas al documento PDF:

- `backend/data/*`: catálogos semilla, inventarios por tienda con apartados, operadores y bitácoras.
- `docs/soa-blueprint.md`: resumen textual de los servicios, estados y transiciones usados.

Cualquier cambio adicional (nuevos RF/RNF) puede implementarse extendiendo las capas `services/` y `routes/` siguiendo la estructura desacoplada.
