﻿export const products = [
  {
    id: 'prd-leche-entera',
    sku: 'LECH-001',
    name: 'Leche Entera 1L',
    shortDescription: 'Leche fresca pasteurizada para el día a día.',
    details: 'Leche entera UHT de 1 litro.',
    price: 4.5,
    unit: 'botella',
    image: 'assets/product-leche.svg',
    category: 'Lácteos',
    tags: ['frescos', 'desayuno'],
    leadTimeMinutes: 40
  },
  {
    id: 'prd-pan-blanco',
    sku: 'PAN-500',
    name: 'Pan Blanco 500g',
    shortDescription: 'Pan tipo molde ideal para sandwich.',
    details: 'Presentación de 500 g de pan molde suave.',
    price: 3.2,
    unit: 'bolsa',
    image: 'assets/product-pan.svg',
    category: 'Panadería',
    tags: ['horneados'],
    leadTimeMinutes: 30
  },
  {
    id: 'prd-huevos-docena',
    sku: 'HUE-012',
    name: 'Huevos de corral (docena)',
    shortDescription: 'Docena de huevos frescos seleccionados.',
    details: 'Huevos AA empacados en bandeja reciclable.',
    price: 6,
    unit: 'bandeja',
    image: 'assets/product-huevos.svg',
    category: 'Huevos',
    tags: ['proteínas'],
    leadTimeMinutes: 25
  },
  {
    id: 'prd-arroz-superior',
    sku: 'ARR-001',
    name: 'Arroz Superior 1Kg',
    shortDescription: 'Grano largo, perfecto para guarniciones.',
    details: 'Saco de 1 kg de arroz extra calidad.',
    price: 2.8,
    unit: 'bolsa',
    image: 'assets/product-arroz.svg',
    category: 'Granos',
    tags: ['despensa'],
    leadTimeMinutes: 20
  },
  {
    id: 'prd-queso-andino',
    sku: 'QUES-210',
    name: 'Queso Andino 250g',
    shortDescription: 'Queso fresco ligeramente salado.',
    details: 'Bloque de 250 g listo para cortar.',
    price: 7.3,
    unit: 'pieza',
    image: 'assets/product-queso.svg',
    category: 'Lácteos',
    tags: ['snacks', 'frescos'],
    leadTimeMinutes: 35
  },
  {
    id: 'prd-cafe-andino',
    sku: 'CAF-110',
    name: 'Café Andino 250g',
    shortDescription: 'Tostado medio, notas de cacao.',
    details: 'Café molido, bolsa resellable de 250 g.',
    price: 18.5,
    unit: 'bolsa',
    image: 'assets/product-cafe.svg',
    category: 'Bebidas',
    tags: ['desayuno', 'premium'],
    leadTimeMinutes: 30
  }
];

export const stores = [
  {
    id: 'lima',
    code: 'PV-LIM-01',
    name: 'Plaza Vea Lima Centro',
    address: 'Av. Garcilaso 1520, Lima',
    timezone: 'America/Lima',
    inventory: {
      'prd-leche-entera': { available: 18, reserved: 0 },
      'prd-pan-blanco': { available: 24, reserved: 0 },
      'prd-huevos-docena': { available: 20, reserved: 0 },
      'prd-arroz-superior': { available: 55, reserved: 0 },
      'prd-queso-andino': { available: 12, reserved: 0 },
      'prd-cafe-andino': { available: 16, reserved: 0 }
    }
  },
  {
    id: 'miraflores',
    code: 'PV-MIR-11',
    name: 'Plaza Vea Miraflores',
    address: 'Av. Pardo 850, Miraflores',
    timezone: 'America/Lima',
    inventory: {
      'prd-leche-entera': { available: 10, reserved: 0 },
      'prd-pan-blanco': { available: 12, reserved: 0 },
      'prd-huevos-docena': { available: 14, reserved: 0 },
      'prd-arroz-superior': { available: 28, reserved: 0 },
      'prd-queso-andino': { available: 8, reserved: 0 },
      'prd-cafe-andino': { available: 9, reserved: 0 }
    }
  },
  {
    id: 'sanisidro',
    code: 'PV-SI-07',
    name: 'Plaza Vea San Isidro',
    address: 'Av. Rivero 320, San Isidro',
    timezone: 'America/Lima',
    inventory: {
      'prd-leche-entera': { available: 9, reserved: 0 },
      'prd-pan-blanco': { available: 15, reserved: 0 },
      'prd-huevos-docena': { available: 11, reserved: 0 },
      'prd-arroz-superior': { available: 33, reserved: 0 },
      'prd-queso-andino': { available: 10, reserved: 0 },
      'prd-cafe-andino': { available: 8, reserved: 0 }
    }
  }
];

export const operators = [
  {
    id: 'op-lim-01',
    name: 'Sofía Ríos',
    storeId: 'lima',
    role: 'supervisor',
    pin: '4321',
    allowedStatuses: ['in_preparation', 'ready', 'cancelled']
  },
  {
    id: 'op-mir-02',
    name: 'Pedro Alvarado',
    storeId: 'miraflores',
    role: 'operador',
    pin: '9876',
    allowedStatuses: ['in_preparation', 'ready']
  },
  {
    id: 'op-sis-03',
    name: 'Ana Vidal',
    storeId: 'sanisidro',
    role: 'operador',
    pin: '2468',
    allowedStatuses: ['in_preparation', 'ready', 'cancelled']
  }
];

export const orders = [
  {
    id: 'd7aab54e-3d60-4a0c-8c6f-1c4ea8a77d11',
    code: 'PV-LIM-20251115-1478',
    storeId: 'lima',
    customer: {
      name: 'Valeria Huamán',
      email: 'valeria@example.com',
      phone: '+51 999 222 111',
      documentId: 'DNI 45896321'
    },
    items: [
      { id: 'prd-leche-entera', name: 'Leche Entera 1L', unitPrice: 4.5, quantity: 2, pickedQuantity: 2, leadTimeMinutes: 40 },
      { id: 'prd-arroz-superior', name: 'Arroz Superior 1Kg', unitPrice: 2.8, quantity: 1, pickedQuantity: 1, leadTimeMinutes: 20 }
    ],
    status: 'ready',
    summary: { currency: 'PEN', total: 11.8, itemsCount: 3 },
    pickupEta: '2025-11-15T17:00:00.000Z',
    history: [
      { status: 'received', label: 'recibido', actor: 'cliente', note: 'Pedido creado desde la web', at: '2025-11-15T15:32:10.000Z' },
      { status: 'in_preparation', label: 'en preparación', actor: 'operador:lima', note: 'Picking iniciado', at: '2025-11-15T15:40:12.000Z' },
      { status: 'ready', label: 'listo para retiro', actor: 'operador:lima', note: 'Pedido listo para retiro', at: '2025-11-15T16:15:18.000Z' }
    ],
    createdAt: '2025-11-15T15:32:10.000Z',
    updatedAt: '2025-11-15T16:15:18.000Z',
    clientRequestId: 'seed-order'
  },
  {
    id: 'f2749cfc-303d-4bb8-ab54-d2df6f73a917',
    code: 'PV-MIR-20251116-2211',
    storeId: 'miraflores',
    customer: {
      name: 'Luis Prado',
      email: 'luis@example.com',
      phone: '+51 988 321 654',
      documentId: 'DNI 40223311'
    },
    items: [
      { id: 'prd-cafe-andino', name: 'Café Andino 250g', unitPrice: 18.5, quantity: 1, pickedQuantity: 0, leadTimeMinutes: 30 },
      { id: 'prd-pan-blanco', name: 'Pan Blanco 500g', unitPrice: 3.2, quantity: 2, pickedQuantity: 0, leadTimeMinutes: 30 }
    ],
    status: 'received',
    summary: { currency: 'PEN', total: 24.9, itemsCount: 3 },
    pickupEta: '2025-11-16T19:00:00.000Z',
    history: [
      { status: 'received', label: 'recibido', actor: 'cliente', note: 'Pedido creado desde la web', at: '2025-11-16T18:10:00.000Z' }
    ],
    createdAt: '2025-11-16T18:10:00.000Z',
    updatedAt: '2025-11-16T18:10:00.000Z',
    clientRequestId: 'seed-order-2'
  }
];

export const events = [
  {
    id: 'evt-001',
    orderId: 'd7aab54e-3d60-4a0c-8c6f-1c4ea8a77d11',
    type: 'state_change',
    actor: 'cliente',
    status: 'received',
    context: { storeId: 'lima', source: 'web' },
    at: '2025-11-15T15:32:10.000Z'
  },
  {
    id: 'evt-002',
    orderId: 'd7aab54e-3d60-4a0c-8c6f-1c4ea8a77d11',
    type: 'state_change',
    actor: 'operador:lima',
    status: 'in_preparation',
    context: { storeId: 'lima' },
    at: '2025-11-15T15:40:12.000Z'
  },
  {
    id: 'evt-003',
    orderId: 'd7aab54e-3d60-4a0c-8c6f-1c4ea8a77d11',
    type: 'state_change',
    actor: 'operador:lima',
    status: 'ready',
    context: { storeId: 'lima' },
    at: '2025-11-15T16:15:18.000Z'
  }
];
