﻿import path from 'path';
import { fileURLToPath } from 'url';
import { writeFile } from 'fs/promises';
import { products, stores, operators, orders, events } from '../seed/baseData.js';
import { sha256 } from '../src/utils/hash.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.resolve(__dirname, '..', 'data');

function toJson(data) {
  return `${JSON.stringify(data, null, 2)}\n`;
}

async function writeJson(filename, data) {
  const filePath = path.join(dataDir, filename);
  await writeFile(filePath, toJson(data), 'utf-8');
  console.log(`✔️  ${filename} regenerado`);
}

function buildOperatorsPayload() {
  return operators.map((operator) => ({
    id: operator.id,
    name: operator.name,
    storeId: operator.storeId,
    role: operator.role,
    pinHash: sha256(operator.pin),
    allowedStatuses: operator.allowedStatuses
  }));
}

async function main() {
  await writeJson('products.json', products);
  await writeJson('inventory.json', { stores });
  await writeJson('operators.json', buildOperatorsPayload());
  await writeJson('orders.json', orders);
  await writeJson('events.json', events);
  console.log('Datos demo reiniciados.');
}

main().catch((error) => {
  console.error('Error al regenerar datos', error);
  process.exit(1);
});
