import { readFileSync, writeFileSync } from 'fs';
import path from 'path';

const inventoryFile = path.resolve(process.cwd(), 'data', 'inventory.json');

/**
 * Load inventory object from file.
 * @returns {Object} Inventory keyed by store id then product id.
 */
function loadInventory() {
  const raw = readFileSync(inventoryFile);
  return JSON.parse(raw);
}

/**
 * Save inventory back to file.
 * @param {Object} data Inventory data
 */
function saveInventory(data) {
  writeFileSync(inventoryFile, JSON.stringify(data, null, 2));
}

/**
 * Get stock for a product at a given store.
 * @param {string} storeId 
 * @param {string} productId 
 * @returns {number|null} Quantity or null if not found
 */
export function getStock(storeId, productId) {
  const inv = loadInventory();
  if (!inv[storeId]) return null;
  const qty = inv[storeId][productId];
  if (typeof qty === 'undefined') return null;
  return qty;
}

/**
 * Reserve stock for an order. If any item has insufficient stock, no changes
 * are persisted and an object describing failures is returned. Otherwise the
 * inventory is decremented accordingly and saved.
 * @param {string} storeId 
 * @param {Array<{id: string, quantity: number}>} items 
 * @returns {Object} { success: boolean, unavailable?: Array, updated?: Array }
 */
export function reserveStock(storeId, items) {
  const inv = loadInventory();
  if (!inv[storeId]) {
    return { success: false, message: 'Tienda no encontrada' };
  }
  const unavailable = [];
  // Check stock
  for (const item of items) {
    const available = inv[storeId][item.id] ?? 0;
    if (available < item.quantity) {
      unavailable.push({ id: item.id, requested: item.quantity, available });
    }
  }
  if (unavailable.length > 0) {
    return { success: false, unavailable };
  }
  // Deduct stock
  for (const item of items) {
    inv[storeId][item.id] -= item.quantity;
  }
  saveInventory(inv);
  return { success: true };
}