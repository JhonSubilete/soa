import { readFileSync } from 'fs';
import path from 'path';

const productsFile = path.resolve(process.cwd(), 'data', 'products.json');

/**
 * Load products from the JSON file.
 * In a real‑world system this would query a database or another microservice.
 * @returns {Array<Object>} List of products
 */
export function getAllProducts() {
  const raw = readFileSync(productsFile);
  return JSON.parse(raw);
}

/**
 * Get a single product by its ID.
 * @param {string} id Product identifier
 * @returns {Object|null}
 */
export function getProductById(id) {
  const products = getAllProducts();
  return products.find((p) => p.id === id) || null;
}