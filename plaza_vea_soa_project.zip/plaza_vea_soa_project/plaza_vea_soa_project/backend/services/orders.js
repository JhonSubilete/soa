import { readFileSync, writeFileSync } from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

const ordersFile = path.resolve(process.cwd(), 'data', 'orders.json');

function loadOrders() {
  try {
    const raw = readFileSync(ordersFile);
    return JSON.parse(raw);
  } catch (err) {
    return [];
  }
}

function saveOrders(data) {
  writeFileSync(ordersFile, JSON.stringify(data, null, 2));
}

export function createOrder({ customer, storeId, items }) {
  const orders = loadOrders();
  const order = {
    id: uuidv4(),
    customer,
    storeId,
    items,
    status: 'recibido',
    history: [{ status: 'recibido', date: new Date().toISOString() }]
  };
  orders.push(order);
  saveOrders(orders);
  return order;
}

export function getOrderById(id) {
  const orders = loadOrders();
  return orders.find((o) => o.id === id) || null;
}

export function updateOrderStatus(id, status) {
  const orders = loadOrders();
  const idx = orders.findIndex((o) => o.id === id);
  if (idx === -1) return null;
  const order = orders[idx];
  order.status = status;
  order.history.push({ status, date: new Date().toISOString() });
  saveOrders(orders);
  return order;
}

export function getOrders() {
  return loadOrders();
}