﻿import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..', '..');

export const config = {
  port: Number(process.env.PORT || 3000),
  dataDir: path.resolve(projectRoot, 'data'),
  requestCacheTtlMs: Number(process.env.REQUEST_CACHE_TTL_MS || 2 * 60 * 1000),
  sessionTtlMs: Number(process.env.SESSION_TTL_MS || 4 * 60 * 60 * 1000)
};
