﻿export const ORDER_STATUSES = ['received', 'in_preparation', 'ready', 'cancelled'];

export const ORDER_TRANSITIONS = {
  received: ['in_preparation', 'cancelled'],
  in_preparation: ['ready', 'cancelled'],
  ready: [],
  cancelled: []
};

export const STATUS_LABELS = {
  received: 'recibido',
  in_preparation: 'en preparacion',
  ready: 'listo para retiro',
  cancelled: 'cancelado'
};

export const DEFAULT_PICKUP_LEAD_MINUTES = 90;
export const REQUEST_CACHE_TTL_MS = 2 * 60 * 1000;
export const SESSION_TTL_MS = 4 * 60 * 60 * 1000;

export const DATA_FILES = Object.freeze({
  products: 'products.json',
  inventory: 'inventory.json',
  orders: 'orders.json',
  events: 'events.json',
  operators: 'operators.json'
});
