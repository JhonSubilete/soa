﻿export const validateRequest = (schema, property = 'body') => (req, res, next) => {
  try {
    const parsed = schema.parse(req[property]);
    req[property] = parsed;
    next();
  } catch (error) {
    next(error);
  }
};
