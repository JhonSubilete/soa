﻿import { accessService } from '../services/accessService.js';
import { UnauthorizedError } from '../utils/errors.js';

function extractToken(req) {
  const header = req.get('Authorization') || '';
  if (header.toLowerCase().startsWith('operator ')) {
    return header.slice(9).trim();
  }
  if (header.toLowerCase().startsWith('bearer ')) {
    return header.slice(7).trim();
  }
  return req.get('x-operator-token');
}

export async function operatorAuth(req, res, next) {
  try {
    const token = extractToken(req);
    if (!token) {
      throw new UnauthorizedError('Token de operador requerido');
    }
    const session = await accessService.verifyToken(token);
    req.operator = session.operator;
    req.operatorToken = token;
    next();
  } catch (error) {
    next(error);
  }
}
