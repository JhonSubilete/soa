﻿import { ZodError } from 'zod';
import { AppError } from '../utils/errors.js';

export function errorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err);
  }

  let statusCode = err.statusCode || 500;
  let message = err.message || 'Error inesperado';
  let details = err.details || null;

  if (err instanceof ZodError) {
    statusCode = 400;
    message = 'Datos invalidos';
    details = err.issues.map((issue) => ({
      path: issue.path.join('.'),
      message: issue.message
    }));
  }

  if (!(err instanceof AppError) && statusCode === 500) {
    console.error('[error]', err);
  }

  res.status(statusCode).json({
    error: message,
    details
  });
}
