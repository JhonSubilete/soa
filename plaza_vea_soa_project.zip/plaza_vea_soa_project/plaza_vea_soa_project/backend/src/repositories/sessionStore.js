﻿import { randomUUID } from 'crypto';
import { config } from '../config/index.js';

const sessions = new Map();

function purgeSessions() {
  const now = Date.now();
  for (const [token, session] of sessions.entries()) {
    if (session.expiresAt <= now) {
      sessions.delete(token);
    }
  }
}

export function createSession(operator) {
  purgeSessions();
  const token = randomUUID();
  const expiresAt = Date.now() + config.sessionTtlMs;
  sessions.set(token, { operator, expiresAt });
  return { token, operator, expiresAt };
}

export function getSession(token) {
  purgeSessions();
  const session = sessions.get(token);
  if (!session) return null;
  if (session.expiresAt <= Date.now()) {
    sessions.delete(token);
    return null;
  }
  return session;
}

export function revokeSession(token) {
  sessions.delete(token);
}
