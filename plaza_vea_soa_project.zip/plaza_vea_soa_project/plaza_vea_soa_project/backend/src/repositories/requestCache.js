﻿import { config } from '../config/index.js';

const cache = new Map();

function purgeExpired() {
  const now = Date.now();
  for (const [key, entry] of cache.entries()) {
    if (entry.expiresAt <= now) {
      cache.delete(key);
    }
  }
}

export function getCachedOrderId(clientRequestId) {
  purgeExpired();
  const entry = cache.get(clientRequestId);
  if (!entry) return null;
  return entry.orderId;
}

export function rememberOrderRequest(clientRequestId, orderId) {
  if (!clientRequestId) return;
  purgeExpired();
  cache.set(clientRequestId, {
    orderId,
    expiresAt: Date.now() + config.requestCacheTtlMs
  });
}
