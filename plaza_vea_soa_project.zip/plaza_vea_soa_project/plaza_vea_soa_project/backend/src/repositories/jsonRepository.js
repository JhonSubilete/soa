﻿import { readFile, writeFile } from 'fs/promises';
import path from 'path';
import { config } from '../config/index.js';

export async function readJson(filename, fallback = null) {
  const filePath = path.join(config.dataDir, filename);
  try {
    let raw = await readFile(filePath, 'utf-8');
    if (raw.charCodeAt(0) === 0xfeff) {
      raw = raw.slice(1);
    }
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (error) {
    if (error.code === 'ENOENT') {
      return fallback;
    }
    throw error;
  }
}

export async function writeJson(filename, data) {
  const filePath = path.join(config.dataDir, filename);
  const payload = JSON.stringify(data, null, 2);
  await writeFile(filePath, payload, 'utf-8');
}
