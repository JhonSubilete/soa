﻿import crypto from 'crypto';

export function generateOrderCode(storeId) {
  const now = new Date();
  const datePart = now.toISOString().slice(2, 10).replace(/-/g, '');
  const storePart = (storeId || 'pv').slice(0, 3).toUpperCase();
  const randomPart = crypto.randomInt(1000, 9999);
  return `PV-${storePart}-${datePart}-${randomPart}`;
}
