﻿import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { operatorAuth } from '../middleware/operatorAuth.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { accessService } from '../services/accessService.js';

const router = Router();

const loginSchema = z.object({
  operatorId: z.string().min(3),
  storeId: z.string().min(2),
  pin: z.string().min(4)
});

router.post(
  '/login',
  validateRequest(loginSchema),
  asyncHandler(async (req, res) => {
    const session = await accessService.login(req.body);
    res.json({
      token: session.token,
      expiresAt: new Date(session.expiresAt).toISOString(),
      operator: session.operator
    });
  })
);

router.post(
  '/logout',
  operatorAuth,
  asyncHandler(async (req, res) => {
    await accessService.logout(req.operatorToken);
    res.status(204).send();
  })
);

export default router;
