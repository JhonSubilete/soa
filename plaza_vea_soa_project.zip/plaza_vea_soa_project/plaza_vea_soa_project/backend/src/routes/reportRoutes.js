﻿import { Router } from 'express';
import { z } from 'zod';
import { operatorAuth } from '../middleware/operatorAuth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { getDailyReport, getOrderTimeline } from '../services/reportService.js';

const router = Router();

const dailyQuerySchema = z.object({
  day: z.string().optional()
});

router.get(
  '/daily',
  operatorAuth,
  validateRequest(dailyQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const report = await getDailyReport(req.query.day);
    res.json(report);
  })
);

router.get(
  '/orders/:orderId/timeline',
  operatorAuth,
  asyncHandler(async (req, res) => {
    const timeline = await getOrderTimeline(req.params.orderId);
    res.json(timeline);
  })
);

export default router;
