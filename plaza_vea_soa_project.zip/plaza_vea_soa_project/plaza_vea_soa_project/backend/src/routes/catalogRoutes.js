﻿import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { listProducts, getProductById } from '../services/catalogService.js';
import { NotFoundError } from '../utils/errors.js';

const router = Router();

const querySchema = z.object({
  q: z.string().optional(),
  storeId: z.string().optional()
});

router.get(
  '/',
  validateRequest(querySchema, 'query'),
  asyncHandler(async (req, res) => {
    const products = await listProducts({ query: req.query.q, storeId: req.query.storeId });
    res.json({ data: products });
  })
);

router.get(
  '/:productId',
  asyncHandler(async (req, res) => {
    const product = await getProductById(req.params.productId);
    if (!product) {
      throw new NotFoundError('Producto no encontrado');
    }
    res.json(product);
  })
);

export default router;
