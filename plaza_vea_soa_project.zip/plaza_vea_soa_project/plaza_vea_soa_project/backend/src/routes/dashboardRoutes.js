﻿import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { getDashboardSummary } from '../services/dashboardService.js';

const router = Router();
const querySchema = z.object({ day: z.string().optional() });

router.get(
  '/',
  validateRequest(querySchema, 'query'),
  asyncHandler(async (req, res) => {
    const summary = await getDashboardSummary(req.query.day);
    res.json(summary);
  })
);

export default router;
