﻿import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { operatorAuth } from '../middleware/operatorAuth.js';
import {
  createOrder,
  getOrderByCode,
  listOrders,
  getOrderById,
  updateOrderStatus,
  updatePicklist,
  toClientOrder
} from '../services/orderService.js';
import { UnauthorizedError } from '../utils/errors.js';

const router = Router();

const createOrderSchema = z.object({
  clientRequestId: z.string().min(8, 'El identificador del pedido es requerido para evitar duplicados'),
  storeId: z.string().min(2),
  customer: z.object({
    name: z.string().min(3),
    email: z.string().email(),
    phone: z.string().min(6),
    documentId: z.string().min(4)
  }),
  items: z.array(
    z.object({
      id: z.string().min(2),
      quantity: z.number().int().positive()
    })
  ).min(1)
});

const listQuerySchema = z.object({
  status: z.enum(['received', 'in_preparation', 'ready', 'cancelled']).optional(),
  storeId: z.string().optional()
});

const statusSchema = z.object({
  status: z.enum(['in_preparation', 'ready', 'cancelled'])
});

const picklistSchema = z.object({
  items: z.array(
    z.object({
      id: z.string().min(2),
      pickedQuantity: z.number().int().min(0)
    })
  ).min(1)
});

router.post(
  '/',
  validateRequest(createOrderSchema),
  asyncHandler(async (req, res) => {
    const order = await createOrder(req.body);
    res.status(201).json(toClientOrder(order));
  })
);

router.get(
  '/track/:code',
  asyncHandler(async (req, res) => {
    const order = await getOrderByCode(req.params.code);
    res.json(order);
  })
);

router.get(
  '/',
  operatorAuth,
  validateRequest(listQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const storeId = req.query.storeId || req.operator.storeId;
    const { status } = req.query;
    const orders = await listOrders({ storeId, status });
    res.json({ data: orders });
  })
);

router.get(
  '/:orderId',
  operatorAuth,
  asyncHandler(async (req, res) => {
    const order = await getOrderById(req.params.orderId);
    if (order.storeId !== req.operator.storeId) {
      throw new UnauthorizedError('No puedes ver pedidos de otra tienda');
    }
    res.json(order);
  })
);

router.put(
  '/:orderId/status',
  operatorAuth,
  validateRequest(statusSchema),
  asyncHandler(async (req, res) => {
    if (!req.operator.allowedStatuses.includes(req.body.status)) {
      throw new UnauthorizedError('No puedes aplicar ese estado');
    }
    const current = await getOrderById(req.params.orderId);
    if (current.storeId !== req.operator.storeId) {
      throw new UnauthorizedError('No puedes modificar pedidos de otra tienda');
    }
    const order = await updateOrderStatus(req.params.orderId, req.body.status, req.operator.name);
    res.json(order);
  })
);

router.put(
  '/:orderId/picklist',
  operatorAuth,
  validateRequest(picklistSchema),
  asyncHandler(async (req, res) => {
    const current = await getOrderById(req.params.orderId);
    if (current.storeId !== req.operator.storeId) {
      throw new UnauthorizedError('No puedes preparar pedidos de otra tienda');
    }
    const order = await updatePicklist(req.params.orderId, req.body.items, req.operator.name);
    res.json(order);
  })
);

export default router;
