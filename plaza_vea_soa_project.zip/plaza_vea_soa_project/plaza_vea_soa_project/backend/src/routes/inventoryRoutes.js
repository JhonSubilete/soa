﻿import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { listStores, getStore, getProductStock } from '../services/inventoryService.js';

const router = Router();

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const stores = await listStores();
    res.json({ data: stores });
  })
);

router.get(
  '/:storeId',
  asyncHandler(async (req, res) => {
    const store = await getStore(req.params.storeId);
    res.json(store);
  })
);

router.get(
  '/:storeId/products/:productId',
  asyncHandler(async (req, res) => {
    const stock = await getProductStock(req.params.storeId, req.params.productId);
    res.json(stock);
  })
);

export default router;
