﻿import { DATA_FILES } from '../config/constants.js';
import { readJson } from '../repositories/jsonRepository.js';
import { createSession, getSession, revokeSession } from '../repositories/sessionStore.js';
import { sha256 } from '../utils/hash.js';
import { UnauthorizedError } from '../utils/errors.js';

async function loadOperators() {
  const operators = await readJson(DATA_FILES.operators, []);
  return Array.isArray(operators) ? operators : [];
}

async function findOperator(operatorId) {
  const operators = await loadOperators();
  return operators.find((op) => op.id === operatorId);
}

export const accessService = {
  async login({ operatorId, storeId, pin }) {
    const operator = await findOperator(operatorId);
    if (!operator || operator.storeId !== storeId) {
      throw new UnauthorizedError('Credenciales invalidas');
    }
    if (operator.pinHash !== sha256(pin)) {
      throw new UnauthorizedError('Pin incorrecto');
    }
    const session = createSession({
      id: operator.id,
      name: operator.name,
      storeId: operator.storeId,
      role: operator.role,
      allowedStatuses: operator.allowedStatuses
    });
    return session;
  },

  async verifyToken(token) {
    const session = getSession(token);
    if (!session) {
      throw new UnauthorizedError('Sesion expirada o invalida');
    }
    return session;
  },

  async logout(token) {
    revokeSession(token);
  }
};
