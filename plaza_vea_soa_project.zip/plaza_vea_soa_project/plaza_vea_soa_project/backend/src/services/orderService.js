﻿import { randomUUID } from 'crypto';
import { DATA_FILES, DEFAULT_PICKUP_LEAD_MINUTES, ORDER_TRANSITIONS, STATUS_LABELS } from '../config/constants.js';
import { readJson, writeJson } from '../repositories/jsonRepository.js';
import { getProductsDictionary } from './catalogService.js';
import { reserveInventory, releaseInventory, consumeReserved } from './inventoryService.js';
import { logEvent } from './eventLogService.js';
import { NotFoundError, ValidationError } from '../utils/errors.js';
import { generateOrderCode } from '../utils/orderCode.js';
import { rememberOrderRequest, getCachedOrderId } from '../repositories/requestCache.js';

async function loadOrders() {
  const orders = await readJson(DATA_FILES.orders, []);
  return Array.isArray(orders) ? orders : [];
}

async function saveOrders(orders) {
  await writeJson(DATA_FILES.orders, orders);
}

function addHistoryEntry(order, status, actor, note) {
  order.history.push({
    status,
    label: STATUS_LABELS[status] || status,
    actor,
    note,
    at: new Date().toISOString()
  });
}

function computePickupEta(items) {
  const longestLead = items.reduce((acc, item) => Math.max(acc, item.leadTimeMinutes || 30), 0);
  const minutes = Math.max(DEFAULT_PICKUP_LEAD_MINUTES, longestLead + 30);
  return new Date(Date.now() + minutes * 60 * 1000).toISOString();
}

function computeSummary(items) {
  return items.reduce(
    (acc, item) => {
      acc.total += item.unitPrice * item.quantity;
      acc.itemsCount += item.quantity;
      return acc;
    },
    { currency: 'PEN', total: 0, itemsCount: 0 }
  );
}

function sanitizeForClient(order) {
  return {
    id: order.id,
    code: order.code,
    storeId: order.storeId,
    customer: {
      name: order.customer.name,
      email: order.customer.email
    },
    items: order.items,
    status: order.status,
    summary: order.summary,
    pickupEta: order.pickupEta,
    history: order.history
  };
}

async function updateStoredOrder(orderId, updater) {
  const orders = await loadOrders();
  const index = orders.findIndex((order) => order.id === orderId);
  if (index === -1) {
    throw new NotFoundError('Pedido no encontrado');
  }
  const order = orders[index];
  await updater(order, orders);
  orders[index] = order;
  await saveOrders(orders);
  return order;
}

export async function listOrders({ storeId, status } = {}) {
  const orders = await loadOrders();
  return orders.filter((order) => {
    if (storeId && order.storeId !== storeId) return false;
    if (status && order.status !== status) return false;
    return true;
  });
}

export async function getOrderById(orderId) {
  const orders = await loadOrders();
  const order = orders.find((entry) => entry.id === orderId);
  if (!order) {
    throw new NotFoundError('Pedido no encontrado');
  }
  return order;
}

export async function getOrderByCode(orderCode) {
  const orders = await loadOrders();
  const normalized = orderCode?.trim().toUpperCase();
  const order = orders.find((entry) => entry.code.toUpperCase() === normalized);
  if (!order) {
    throw new NotFoundError('Pedido no encontrado');
  }
  return sanitizeForClient(order);
}

export async function createOrder({ clientRequestId, customer, storeId, items }) {
  if (clientRequestId) {
    const cachedOrderId = getCachedOrderId(clientRequestId);
    if (cachedOrderId) {
      return await getOrderById(cachedOrderId);
    }
  }

  const productsDictionary = await getProductsDictionary();
  const normalizedItems = items.map((item) => {
    const product = productsDictionary[item.id];
    if (!product) {
      throw new ValidationError(`Producto con id ${item.id} no existe`);
    }
    return {
      id: product.id,
      name: product.name,
      unitPrice: product.price,
      quantity: item.quantity,
      pickedQuantity: 0,
      leadTimeMinutes: product.leadTimeMinutes || 30
    };
  });

  const reserve = await reserveInventory(
    storeId,
    normalizedItems.map((item) => ({ id: item.id, quantity: item.quantity }))
  );

  if (!reserve.success) {
    throw new ValidationError('Stock insuficiente', reserve.insufficient);
  }

  const now = new Date().toISOString();
  const order = {
    id: randomUUID(),
    code: generateOrderCode(storeId),
    storeId,
    customer,
    items: normalizedItems,
    status: 'received',
    summary: computeSummary(normalizedItems),
    pickupEta: computePickupEta(normalizedItems),
    history: [],
    createdAt: now,
    updatedAt: now,
    clientRequestId
  };
  addHistoryEntry(order, 'received', 'cliente', 'Pedido creado desde la web');

  const existingOrders = await loadOrders();
  existingOrders.push(order);
  await saveOrders(existingOrders);

  await logEvent({
    orderId: order.id,
    type: 'state_change',
    actor: 'cliente',
    status: 'received',
    context: { storeId, source: 'web' }
  });

  rememberOrderRequest(clientRequestId, order.id);
  return order;
}

export async function updateOrderStatus(orderId, newStatus, actor = 'operador') {
  return updateStoredOrder(orderId, async (order) => {
    if (order.status === newStatus) {
      return;
    }

    // Permitir que un pedido pase directo de recibido a listo => se inserta paso intermedio
    if (newStatus === 'ready' && order.status === 'received') {
      order.status = 'in_preparation';
      order.updatedAt = new Date().toISOString();
      addHistoryEntry(order, 'in_preparation', actor, 'Paso directo a listo');
      await logEvent({
        orderId: order.id,
        type: 'state_change',
        actor,
        status: 'in_preparation',
        context: { storeId: order.storeId }
      });
    }

    const allowed = ORDER_TRANSITIONS[order.status] || [];
    if (!allowed.includes(newStatus)) {
      throw new ValidationError(`Transicion no permitida de ${order.status} a ${newStatus}`);
    }

    if (newStatus === 'cancelled' && order.status !== 'ready') {
      await releaseInventory(
        order.storeId,
        order.items.map((item) => ({ id: item.id, quantity: item.quantity }))
      );
    }

    if (newStatus === 'ready') {
      await consumeReserved(
        order.storeId,
        order.items.map((item) => ({ id: item.id, quantity: item.quantity }))
      );
    }

    order.status = newStatus;
    order.updatedAt = new Date().toISOString();
    addHistoryEntry(order, newStatus, actor, 'Estado actualizado');

    await logEvent({
      orderId: order.id,
      type: 'state_change',
      actor,
      status: newStatus,
      context: { storeId: order.storeId }
    });
  });
}

export async function updatePicklist(orderId, pickedItems, actor = 'operador') {
  return updateStoredOrder(orderId, async (order) => {
    const itemsMap = new Map(pickedItems.map((item) => [item.id, item.pickedQuantity]));
    order.items = order.items.map((item) => ({
      ...item,
      pickedQuantity: typeof itemsMap.get(item.id) === 'number'
        ? itemsMap.get(item.id)
        : item.pickedQuantity
    }));

    const allPicked = order.items.every((item) => item.pickedQuantity >= item.quantity);
    const somePicked = order.items.some((item) => item.pickedQuantity > 0);

    if (order.status === 'received' && somePicked) {
      order.status = 'in_preparation';
      addHistoryEntry(order, 'in_preparation', actor, 'Picking iniciado');
      await logEvent({
        orderId: order.id,
        type: 'state_change',
        actor,
        status: 'in_preparation',
        context: { storeId: order.storeId }
      });
    }

    if (allPicked && order.status !== 'ready') {
      await consumeReserved(
        order.storeId,
        order.items.map((item) => ({ id: item.id, quantity: item.quantity }))
      );
      order.status = 'ready';
      addHistoryEntry(order, 'ready', actor, 'Pedido listo para retiro');
      await logEvent({
        orderId: order.id,
        type: 'state_change',
        actor,
        status: 'ready',
        context: { storeId: order.storeId }
      });
    }

    order.updatedAt = new Date().toISOString();
  });
}

export function toClientOrder(order) {
  return sanitizeForClient(order);
}
