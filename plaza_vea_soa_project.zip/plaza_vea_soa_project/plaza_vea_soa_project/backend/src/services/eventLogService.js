﻿import { randomUUID } from 'crypto';
import { DATA_FILES } from '../config/constants.js';
import { readJson, writeJson } from '../repositories/jsonRepository.js';

async function loadEvents() {
  const events = await readJson(DATA_FILES.events, []);
  return Array.isArray(events) ? events : [];
}

async function saveEvents(events) {
  await writeJson(DATA_FILES.events, events);
}

export async function logEvent({ orderId, type, actor, status, context }) {
  const events = await loadEvents();
  const payload = {
    id: randomUUID(),
    orderId,
    type,
    actor,
    status,
    context,
    at: new Date().toISOString()
  };
  events.push(payload);
  await saveEvents(events);
  return payload;
}

export async function listEventsByOrder(orderId) {
  const events = await loadEvents();
  return events.filter((event) => event.orderId === orderId);
}

export async function getEvents() {
  return loadEvents();
}

export async function getDailySummary(dateString) {
  const events = await loadEvents();
  const targetDate = dateString ? new Date(dateString) : new Date();
  const day = targetDate.toISOString().slice(0, 10);
  const filtered = events.filter((event) => event.at?.slice(0, 10) === day);

  const totals = {
    totalEvents: filtered.length,
    statusChanges: 0,
    errors: 0,
    byStatus: {},
    byStore: {}
  };

  for (const event of filtered) {
    if (event.type === 'state_change') {
      totals.statusChanges += 1;
      if (event.status) {
        totals.byStatus[event.status] = (totals.byStatus[event.status] || 0) + 1;
      }
    }
    if (event.type === 'error') {
      totals.errors += 1;
    }
    const storeId = event.context?.storeId;
    if (storeId) {
      totals.byStore[storeId] = (totals.byStore[storeId] || 0) + 1;
    }
  }

  return { day, ...totals };
}
