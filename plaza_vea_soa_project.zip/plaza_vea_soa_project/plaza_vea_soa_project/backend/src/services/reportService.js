﻿import { listOrders, getOrderById } from './orderService.js';
import { getDailySummary as getDailyEventsSummary, listEventsByOrder } from './eventLogService.js';

export async function getDailyReport(dayString) {
  const day = dayString || new Date().toISOString().slice(0, 10);
  const orders = await listOrders();
  const filtered = orders.filter((order) => order.createdAt?.slice(0, 10) === day);

  const summary = {
    totalOrders: filtered.length,
    revenue: filtered.reduce((acc, order) => acc + (order.summary?.total || 0), 0),
    byStatus: filtered.reduce((acc, order) => {
      acc[order.status] = (acc[order.status] || 0) + 1;
      return acc;
    }, {}),
    byStore: filtered.reduce((acc, order) => {
      acc[order.storeId] = (acc[order.storeId] || 0) + 1;
      return acc;
    }, {})
  };

  const events = await getDailyEventsSummary(day);
  return { day, orders: summary, events };
}

export async function getOrderTimeline(orderId) {
  const order = await getOrderById(orderId);
  const events = await listEventsByOrder(orderId);
  return {
    orderId,
    history: order.history,
    events
  };
}
