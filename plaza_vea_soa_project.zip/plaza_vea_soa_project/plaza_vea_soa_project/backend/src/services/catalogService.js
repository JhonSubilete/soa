﻿import { DATA_FILES } from '../config/constants.js';
import { readJson } from '../repositories/jsonRepository.js';
import { getStoreInventoryMap } from './inventoryService.js';

async function loadProducts() {
  const products = await readJson(DATA_FILES.products, []);
  return Array.isArray(products) ? products : [];
}

export async function listProducts({ query, storeId } = {}) {
  const products = await loadProducts();
  const normalizedQuery = query?.trim().toLowerCase();
  let filtered = products;
  if (normalizedQuery) {
    filtered = filtered.filter((product) => {
      return (
        product.name?.toLowerCase().includes(normalizedQuery) ||
        product.shortDescription?.toLowerCase().includes(normalizedQuery) ||
        product.category?.toLowerCase().includes(normalizedQuery)
      );
    });
  }

  let availabilityByProduct = null;
  if (storeId) {
    availabilityByProduct = await getStoreInventoryMap(storeId);
    filtered = filtered.filter((product) => {
      const stock = availabilityByProduct[product.id];
      return stock?.available > 0;
    });
  }

  return filtered.map((product) => ({
    ...product,
    availability: storeId && availabilityByProduct
      ? availabilityByProduct[product.id] || { available: 0, reserved: 0 }
      : undefined
  }));
}

export async function getProductById(productId) {
  const products = await loadProducts();
  return products.find((product) => product.id === productId) || null;
}

export async function getProductsDictionary() {
  const products = await loadProducts();
  return products.reduce((acc, product) => {
    acc[product.id] = product;
    return acc;
  }, {});
}
