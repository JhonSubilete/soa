﻿import { listOrders } from './orderService.js';
import { listStores } from './inventoryService.js';
import { getProductsDictionary } from './catalogService.js';

function isSameDay(timestamp, dayString) {
  if (!timestamp) return false;
  return timestamp.slice(0, 10) === dayString;
}

function buildStoreStats(stores, orders) {
  return stores.map((store) => {
    const storeOrders = orders.filter((order) => order.storeId === store.id);
    const byStatus = storeOrders.reduce((acc, order) => {
      acc[order.status] = (acc[order.status] || 0) + 1;
      return acc;
    }, {});
    return {
      id: store.id,
      name: store.name,
      code: store.code,
      address: store.address,
      inventoryLowStock: store.inventorySummary.lowStock,
      orders: {
        total: storeOrders.length,
        ready: byStatus.ready || 0,
        inPreparation: byStatus.in_preparation || 0,
        received: byStatus.received || 0,
        cancelled: byStatus.cancelled || 0
      }
    };
  });
}

function buildTopProducts(orders) {
  const ranking = new Map();
  for (const order of orders) {
    for (const item of order.items) {
      const current = ranking.get(item.id) || { id: item.id, name: item.name, quantity: 0, revenue: 0 };
      current.quantity += item.quantity;
      current.revenue += (item.unitPrice || 0) * item.quantity;
      ranking.set(item.id, current);
    }
  }
  return Array.from(ranking.values())
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 5);
}

export async function getDashboardSummary(day) {
  const dayString = day || new Date().toISOString().slice(0, 10);
  const [orders, stores, productsDict] = await Promise.all([
    listOrders(),
    listStores(),
    getProductsDictionary()
  ]);

  const ordersToday = orders.filter((order) => isSameDay(order.createdAt, dayString));
  const totalsToday = ordersToday.reduce(
    (acc, order) => {
      acc.count += 1;
      acc.revenue += order.summary?.total || 0;
      acc.byStatus[order.status] = (acc.byStatus[order.status] || 0) + 1;
      return acc;
    },
    { count: 0, revenue: 0, byStatus: {} }
  );

  const topProducts = buildTopProducts(orders);
  const enrichedTopProducts = topProducts.map((item) => ({
    ...item,
    image: productsDict[item.id]?.image,
    category: productsDict[item.id]?.category
  }));

  const storeStats = buildStoreStats(stores, orders);
  const lastOrders = orders
    .slice()
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5)
    .map((order) => ({
      id: order.id,
      code: order.code,
      storeId: order.storeId,
      status: order.status,
      summary: order.summary,
      createdAt: order.createdAt,
      customer: order.customer?.name
    }));

  return {
    day: dayString,
    totals: {
      orders: totalsToday.count,
      revenue: totalsToday.revenue,
      byStatus: totalsToday.byStatus
    },
    stores: storeStats,
    topProducts: enrichedTopProducts,
    lastOrders
  };
}
