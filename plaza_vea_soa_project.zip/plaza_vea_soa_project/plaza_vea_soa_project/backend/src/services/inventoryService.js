﻿import { DATA_FILES } from '../config/constants.js';
import { readJson, writeJson } from '../repositories/jsonRepository.js';
import { NotFoundError } from '../utils/errors.js';

async function loadInventory() {
  const data = await readJson(DATA_FILES.inventory, { stores: [] });
  return data.stores || [];
}

async function saveInventory(stores) {
  await writeJson(DATA_FILES.inventory, { stores });
}

function findStoreOrThrow(stores, storeId) {
  const store = stores.find((entry) => entry.id === storeId);
  if (!store) {
    throw new NotFoundError('Tienda no encontrada');
  }
  if (!store.inventory) {
    store.inventory = {};
  }
  return store;
}

function cloneInventory(inventory = {}) {
  const snapshot = {};
  for (const [productId, data] of Object.entries(inventory)) {
    snapshot[productId] = { ...data };
  }
  return snapshot;
}

export async function listStores() {
  const stores = await loadInventory();
  return stores.map((store) => ({
    id: store.id,
    code: store.code,
    name: store.name,
    address: store.address,
    timezone: store.timezone,
    inventorySummary: Object.entries(store.inventory || {}).reduce(
      (acc, [productId, info]) => {
        acc.totalProducts += info.available;
        if (info.available < 5) acc.lowStock.push(productId);
        return acc;
      },
      { totalProducts: 0, lowStock: [] }
    )
  }));
}

export async function getStore(storeId) {
  const stores = await loadInventory();
  const store = findStoreOrThrow(stores, storeId);
  return {
    ...store,
    inventory: cloneInventory(store.inventory)
  };
}

export async function getStoreInventoryMap(storeId) {
  const stores = await loadInventory();
  const store = findStoreOrThrow(stores, storeId);
  return cloneInventory(store.inventory);
}

export async function getProductStock(storeId, productId) {
  const stores = await loadInventory();
  const store = findStoreOrThrow(stores, storeId);
  const record = store.inventory?.[productId];
  if (!record) {
    throw new NotFoundError('Producto sin inventario registrado en la tienda solicitada');
  }
  return { productId, storeId, ...record };
}

export async function reserveInventory(storeId, items) {
  const stores = await loadInventory();
  const store = findStoreOrThrow(stores, storeId);
  const insufficient = [];

  for (const item of items) {
    const record = store.inventory?.[item.id];
    const available = record?.available ?? 0;
    if (available < item.quantity) {
      insufficient.push({ productId: item.id, requested: item.quantity, available });
    }
  }

  if (insufficient.length > 0) {
    return { success: false, insufficient };
  }

  for (const item of items) {
    if (!store.inventory[item.id]) {
      store.inventory[item.id] = { available: 0, reserved: 0 };
    }
    store.inventory[item.id].available -= item.quantity;
    store.inventory[item.id].reserved += item.quantity;
  }

  await saveInventory(stores);
  return { success: true };
}

export async function releaseInventory(storeId, items) {
  const stores = await loadInventory();
  const store = findStoreOrThrow(stores, storeId);
  for (const item of items) {
    if (!store.inventory[item.id]) {
      store.inventory[item.id] = { available: 0, reserved: 0 };
    }
    store.inventory[item.id].available += item.quantity;
    store.inventory[item.id].reserved = Math.max(0, (store.inventory[item.id].reserved || 0) - item.quantity);
  }
  await saveInventory(stores);
}

export async function consumeReserved(storeId, items) {
  const stores = await loadInventory();
  const store = findStoreOrThrow(stores, storeId);
  for (const item of items) {
    if (!store.inventory[item.id]) continue;
    store.inventory[item.id].reserved = Math.max(0, (store.inventory[item.id].reserved || 0) - item.quantity);
  }
  await saveInventory(stores);
}
