﻿import { API_BASE, FALLBACK_STORES, getFallbackProductsForStore, formatCurrency, fetchJson } from './common.js';

const ORDER_STORAGE_KEY = 'pv-last-order';

const state = {
  stores: [],
  selectedStore: null,
  products: [],
  cart: [],
  lastOrder: null,
  submitting: false
};

const elements = {
  catalogStoreSelect: document.getElementById('catalog-store-select'),
  storeSelect: document.getElementById('store-select'),
  productList: document.getElementById('product-list'),
  productSearch: document.getElementById('product-search'),
  catalogWarning: document.getElementById('catalog-warning'),
  cartItems: document.getElementById('cart-items'),
  cartTotal: document.getElementById('cart-total'),
  checkoutBtn: document.getElementById('checkout-btn'),
  clearCart: document.getElementById('clear-cart'),
  checkoutForm: document.getElementById('checkout-form'),
  checkoutSubmit: document.getElementById('checkout-submit'),
  orderMessage: document.getElementById('order-message'),
  confirmationCode: document.getElementById('confirmation-code'),
  confirmationStatus: document.getElementById('confirmation-status'),
  confirmationStore: document.getElementById('confirmation-store'),
  confirmationTotal: document.getElementById('confirmation-total'),
  confirmationItems: document.getElementById('confirmation-items'),
  confirmationNew: document.getElementById('confirmation-new'),
  confirmationTrack: document.getElementById('confirmation-track'),
  heroCartItems: document.getElementById('hero-cart-items'),
  heroStore: document.getElementById('hero-store')
};

init();

function init() {
  bindEvents();
  loadStores().then(() => {
    state.selectedStore = state.stores[0]?.id || 'lima';
    syncStoreSelects();
    loadProducts();
  });
  renderCart();
  hydrateFromStorage();
  renderSummary();
}

function bindEvents() {
  elements.productSearch.addEventListener('input', debounce(() => loadProducts(), 300));
  elements.catalogStoreSelect.addEventListener('change', () => {
    state.selectedStore = elements.catalogStoreSelect.value;
    syncStoreSelects();
    loadProducts();
  });
  elements.clearCart.addEventListener('click', () => {
    state.cart = [];
    renderCart();
  });
  elements.checkoutBtn.addEventListener('click', () => {
    elements.checkoutForm.scrollIntoView({ behavior: 'smooth' });
  });
  elements.checkoutForm.addEventListener('submit', handleCheckout);
  if (elements.confirmationNew) {
    elements.confirmationNew.addEventListener('click', () => {
      state.lastOrder = null;
      sessionStorage.removeItem(ORDER_STORAGE_KEY);
      renderSummary();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
  if (elements.confirmationTrack) {
    elements.confirmationTrack.addEventListener('click', () => {
      if (state.lastOrder) {
        localStorage.setItem('pv-last-code', state.lastOrder.code);
      }
    });
  }
}

async function loadStores() {
  try {
    const data = await fetchJson(`${API_BASE}/stores`);
    state.stores = data.data || [];
    populateStoreSelects();
    elements.catalogWarning.textContent = '';
  } catch (error) {
    console.warn('Stores fallback', error.message);
    state.stores = FALLBACK_STORES;
    populateStoreSelects();
    elements.catalogWarning.textContent = 'Backend no disponible, usando datos demo.';
  }
}

async function loadProducts() {
  try {
    const params = new URLSearchParams();
    if (state.selectedStore) params.append('storeId', state.selectedStore);
    const q = elements.productSearch.value.trim();
    if (q) params.append('q', q);
    const data = await fetchJson(`${API_BASE}/catalog?${params.toString()}`);
    state.products = data.data || [];
  } catch (error) {
    console.warn('Products fallback', error.message);
    state.products = getFallbackProductsForStore(state.selectedStore || 'lima');
  }
  renderProducts();
}

function populateStoreSelects() {
  const options = state.stores.map((store) => `<option value="${store.id}">${store.name}</option>`).join('');
  elements.catalogStoreSelect.innerHTML = options;
  elements.storeSelect.innerHTML = options;
}

function syncStoreSelects() {
  elements.catalogStoreSelect.value = state.selectedStore;
  elements.storeSelect.value = state.selectedStore;
  updateHeroInfo();
}

function renderProducts() {
  if (!state.products.length) {
    elements.productList.innerHTML = '<p class="muted">No hay productos para esta tienda.</p>';
    return;
  }
  elements.productList.innerHTML = state.products
    .map((product) => {
      const availability = product.availability?.available ?? '—';
      return `
        <article class="product-card">
          <span class="pill">${product.category || 'Supermercado'}</span>
          <img src="${product.image}" alt="${product.name}" />
          <h4>${product.name}</h4>
          <p class="muted">${product.shortDescription}</p>
          <div class="price">${formatCurrency(product.price)} · Stock ${availability}</div>
          <button class="btn primary" data-id="${product.id}">Agregar</button>
        </article>`;
    })
    .join('');
  elements.productList.querySelectorAll('button').forEach((btn) => {
    btn.addEventListener('click', () => addToCart(btn.dataset.id));
  });
}

function addToCart(productId) {
  const product = state.products.find((p) => p.id === productId);
  if (!product) return;
  const availability = product.availability?.available ?? Infinity;
  const existing = state.cart.find((item) => item.id === productId);
  if (existing) {
    if (existing.quantity >= availability) return;
    existing.quantity += 1;
  } else {
    state.cart.push({ id: productId, quantity: 1 });
  }
  renderCart();
}

function updateQuantity(productId, delta) {
  const item = state.cart.find((entry) => entry.id === productId);
  if (!item) return;
  item.quantity += delta;
  if (item.quantity <= 0) {
    state.cart = state.cart.filter((entry) => entry.id !== productId);
  }
  renderCart();
}

function renderCart() {
  if (!state.cart.length) {
    elements.cartItems.innerHTML = '<p class="muted">Tu carrito está vacío.</p>';
    elements.cartTotal.textContent = 'Total: S/ 0.00';
    elements.checkoutBtn.disabled = true;
    updateHeroInfo();
    return;
  }
  const rows = state.cart
    .map((item) => {
      const product = state.products.find((p) => p.id === item.id);
      return `
        <div class="cart-item" data-id="${item.id}">
          <div>
            <strong>${product?.name || 'Producto'}</strong>
            <p class="muted">${item.quantity} x ${formatCurrency(product?.price || 0)}</p>
          </div>
          <div>
            <button class="btn ghost" data-action="dec">-</button>
            <button class="btn ghost" data-action="inc">+</button>
            <button class="btn ghost" data-action="remove">Eliminar</button>
          </div>
        </div>`;
    })
    .join('');
  elements.cartItems.innerHTML = rows;
  elements.cartItems.querySelectorAll('.cart-item').forEach((node) => {
    node.querySelectorAll('button').forEach((btn) => {
      const action = btn.dataset.action;
      const id = node.dataset.id;
      btn.addEventListener('click', () => {
        if (action === 'dec') updateQuantity(id, -1);
        if (action === 'inc') updateQuantity(id, 1);
        if (action === 'remove') {
          state.cart = state.cart.filter((entry) => entry.id !== id);
          renderCart();
        }
      });
    });
  });
  const total = state.cart.reduce((acc, item) => {
    const product = state.products.find((p) => p.id === item.id);
    return acc + (product?.price || 0) * item.quantity;
  }, 0);
  elements.cartTotal.textContent = `Total: ${formatCurrency(total)}`;
  elements.checkoutBtn.disabled = false;
  updateHeroInfo();
}

async function handleCheckout(event) {
  event.preventDefault();
  if (state.submitting) return;
  if (!state.cart.length) {
    showMessage('Agrega productos al carrito.');
    return;
  }
  const payload = {
    clientRequestId: createRequestId(),
    storeId: elements.storeSelect.value,
    customer: {
      name: document.getElementById('customer-name').value,
      email: document.getElementById('customer-email').value,
      phone: document.getElementById('customer-phone').value,
      documentId: document.getElementById('customer-document').value
    },
    items: state.cart.map((item) => ({ id: item.id, quantity: item.quantity }))
  };
  try {
    state.submitting = true;
    elements.checkoutSubmit.disabled = true;
    const order = await fetchJson(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    state.lastOrder = order;
    renderSummary();
    showMessage(`Pedido ${order.code} en estado ${order.status}.`, true);
    state.cart = [];
    renderCart();
    elements.checkoutForm.reset();
    window.scrollTo({ top: document.getElementById('confirmation-panel').offsetTop - 60, behavior: 'smooth' });
  } catch (error) {
    showMessage(error.message || 'No se pudo crear el pedido');
  } finally {
    state.submitting = false;
    elements.checkoutSubmit.disabled = false;
  }
}

function renderSummary() {
  if (!state.lastOrder) {
    elements.confirmationCode.textContent = 'Aún no confirmas';
    elements.confirmationStatus.textContent = '';
    elements.confirmationStore.textContent = '';
    elements.confirmationTotal.textContent = '';
    elements.confirmationItems.innerHTML = '<li class="muted">Confirma un pedido para ver el resumen.</li>';
    return;
  }
  const order = state.lastOrder;
  elements.confirmationCode.textContent = order.code;
  elements.confirmationStatus.textContent = order.status;
  const store = state.stores.find((s) => s.id === order.storeId);
  elements.confirmationStore.textContent = `${store?.name || order.storeId} · ${order.customer.name}`;
  elements.confirmationTotal.textContent = `Total ${formatCurrency(order.summary?.total || 0)} · ${order.summary?.itemsCount || order.items.length} productos`;
  elements.confirmationItems.innerHTML = order.items
    .map((item) => `<li><span>${item.name} x ${item.quantity}</span><strong>${formatCurrency(item.unitPrice * item.quantity)}</strong></li>`)
    .join('');

  sessionStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(order));
}

function showMessage(message, success = false) {
  elements.orderMessage.textContent = message;
  elements.orderMessage.style.borderColor = success ? 'rgba(15,157,88,0.4)' : 'rgba(230,0,35,0.3)';
}

function createRequestId() {
  return `web-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function debounce(fn, delay) {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => fn(...args), delay);
  };
}

function hydrateFromStorage() {
  const stored = sessionStorage.getItem(ORDER_STORAGE_KEY);
  if (!stored) return;
  try {
    state.lastOrder = JSON.parse(stored);
  } catch (error) {
    console.warn('No se pudo restaurar el último pedido', error);
  }
}

function updateHeroInfo() {
  if (elements.heroCartItems) {
    const items = state.cart.reduce((total, item) => total + item.quantity, 0);
    elements.heroCartItems.textContent = items;
  }
  if (elements.heroStore) {
    const store = state.stores.find((s) => s.id === state.selectedStore);
    elements.heroStore.textContent = store?.name || '--';
  }
}
