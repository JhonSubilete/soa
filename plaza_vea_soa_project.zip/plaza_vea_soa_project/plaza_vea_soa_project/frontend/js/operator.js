﻿import { API_BASE, FALLBACK_STORES, fetchJson, formatCurrency } from './common.js';

const state = {
  token: null,
  profile: null,
  orders: [],
  filterStatus: 'received',
  selectedOrderId: null,
  stores: []
};

const elements = {
  storeSelect: document.getElementById('operator-store'),
  loginForm: document.getElementById('operator-login-form'),
  operatorId: document.getElementById('operator-id'),
  operatorPin: document.getElementById('operator-pin'),
  logoutBtn: document.getElementById('operator-logout'),
  message: document.getElementById('operator-message'),
  summary: document.getElementById('operator-summary'),
  orderList: document.getElementById('operator-order-list'),
  detail: document.getElementById('operator-detail')
};

init();

async function init() {
  await loadStores();
  bindEvents();
}

function bindEvents() {
  elements.loginForm.addEventListener('submit', handleLogin);
  elements.logoutBtn.addEventListener('click', handleLogout);
  document.querySelectorAll('.status-filters .pill').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.filterStatus = btn.dataset.status;
      highlightStatus();
      loadOrders();
    });
  });
}

async function loadStores() {
  try {
    const data = await fetchJson(`${API_BASE}/stores`);
    state.stores = data.data || [];
  } catch (error) {
    state.stores = FALLBACK_STORES;
  }
  elements.storeSelect.innerHTML = state.stores.map((store) => `<option value="${store.id}">${store.name}</option>`).join('');
}

async function handleLogin(event) {
  event.preventDefault();
  try {
    const payload = {
      storeId: elements.storeSelect.value,
      operatorId: elements.operatorId.value,
      pin: elements.operatorPin.value
    };
    const session = await fetchJson(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    state.token = session.token;
    state.profile = session.operator;
    state.filterStatus = 'received';
    state.selectedOrderId = null;
    showMessage(`Sesión iniciada por ${session.operator.name}`, true);
    elements.logoutBtn.disabled = false;
    highlightStatus();
    loadOrders();
  } catch (error) {
    showMessage(error.message || 'Error al iniciar sesión');
  }
}

async function handleLogout() {
  if (!state.token) return;
  await fetch(`${API_BASE}/auth/logout`, {
    method: 'POST',
    headers: { Authorization: `Operator ${state.token}` }
  }).catch(() => {});
  state.token = null;
  state.profile = null;
  state.orders = [];
  state.selectedOrderId = null;
  elements.logoutBtn.disabled = true;
  showMessage('Sesión cerrada.', true);
  renderOrders();
  renderDetail();
}

async function loadOrders() {
  if (!state.token) return;
  const params = new URLSearchParams();
  if (state.filterStatus) params.set('status', state.filterStatus);
  try {
    const data = await fetchJson(`${API_BASE}/orders?${params.toString()}`, {
      headers: { Authorization: `Operator ${state.token}` }
    });
    state.orders = data.data || [];
    renderOrders();
  } catch (error) {
    showMessage(error.message || 'No se pudieron cargar pedidos');
  }
}

function renderOrders() {
  if (!state.orders.length) {
    elements.orderList.innerHTML = '<p class="muted">No hay pedidos.</p>';
    elements.summary.textContent = '';
    return;
  }
  elements.summary.textContent = `${state.orders.length} pedidos · ${state.filterStatus}`;
  elements.orderList.innerHTML = state.orders
    .map((order) => `
      <article class="order-card ${state.selectedOrderId === order.id ? 'active' : ''}" data-id="${order.id}">
        <header><span>${order.code}</span><span class="pill">${order.status}</span></header>
        <p class="muted">${order.summary.itemsCount} productos · ${formatCurrency(order.summary.total)}</p>
      </article>`)
    .join('');
  elements.orderList.querySelectorAll('.order-card').forEach((card) => {
    card.addEventListener('click', () => {
      state.selectedOrderId = card.dataset.id;
      renderOrders();
      renderDetail();
    });
  });
  renderDetail();
}

async function renderDetail() {
  const container = elements.detail;
  if (!state.selectedOrderId) {
    container.innerHTML = '<p class="muted">Selecciona un pedido.</p>';
    return;
  }
  const order = state.orders.find((o) => o.id === state.selectedOrderId);
  if (!order) {
    container.innerHTML = '<p class="muted">Pedido no disponible.</p>';
    return;
  }
  const items = order.items
    .map((item) => `
      <div class="picklist-item">
        <div>
          <strong>${item.name}</strong>
          <p class="muted">Solicitado ${item.quantity} · Recogido ${item.pickedQuantity || 0}</p>
        </div>
        <input type="number" min="0" max="${item.quantity}" value="${item.pickedQuantity || 0}" data-id="${item.id}" />
      </div>`)
    .join('');
  container.innerHTML = `
    <div>
      <h4>${order.code}</h4>
      <p class="muted">${order.customer.name} · ${order.summary.itemsCount} items</p>
    </div>
    <div class="picklist">${items}</div>
    <div class="operator-actions">
      <button class="btn primary" id="save-picklist">Guardar picking</button>
      <button class="btn ghost" data-status="ready">Marcar listo</button>
      <button class="btn ghost" data-status="cancelled">Cancelar</button>
    </div>
    <div id="operator-detail-message" class="alert"></div>
    <div id="operator-timeline" class="operator-timeline"></div>`;
  container.querySelector('#save-picklist').addEventListener('click', () => submitPicklist(order.id));
  container.querySelectorAll('[data-status]').forEach((btn) => {
    btn.addEventListener('click', () => submitStatus(order.id, btn.dataset.status));
  });
  loadTimeline(order.id);
}

async function submitPicklist(orderId) {
  const inputs = Array.from(elements.detail.querySelectorAll('.picklist-item input'));
  const items = inputs.map((input) => ({ id: input.dataset.id, pickedQuantity: Number(input.value) }));
  try {
    await fetchJson(`${API_BASE}/orders/${orderId}/picklist`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Operator ${state.token}` },
      body: JSON.stringify({ items })
    });
    showDetailMessage('Picklist actualizado', true);
    loadOrders();
  } catch (error) {
    showDetailMessage(error.message);
  }
}

async function submitStatus(orderId, status) {
  try {
    await fetchJson(`${API_BASE}/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Operator ${state.token}` },
      body: JSON.stringify({ status })
    });
    showDetailMessage(`Pedido ${status}` , true);
    loadOrders();
  } catch (error) {
    showDetailMessage(error.message);
  }
}

async function loadTimeline(orderId) {
  try {
    const data = await fetchJson(`${API_BASE}/reports/orders/${orderId}/timeline`, {
      headers: { Authorization: `Operator ${state.token}` }
    });
    const history = data.history
      .map((entry) => `<div class="item"><strong>${entry.status}</strong><p class="muted">${new Date(entry.at).toLocaleString()}</p></div>`)
      .join('');
    document.getElementById('operator-timeline').innerHTML = `<div class="timeline">${history}</div>`;
  } catch (error) {
    document.getElementById('operator-timeline').innerHTML = '<p class="muted">No se pudo cargar el historial.</p>';
  }
}

function highlightStatus() {
  document.querySelectorAll('.status-filters .pill').forEach((btn) => {
    btn.classList.toggle('success', btn.dataset.status === state.filterStatus);
  });
}

function showMessage(message, success = false) {
  elements.message.textContent = message;
  elements.message.style.borderColor = success ? 'rgba(15,157,88,0.4)' : 'rgba(230,0,35,0.3)';
}

function showDetailMessage(message, success = false) {
  const node = document.getElementById('operator-detail-message');
  if (node) {
    node.textContent = message;
    node.style.borderColor = success ? 'rgba(15,157,88,0.4)' : 'rgba(230,0,35,0.3)';
  }
}
