﻿import { API_BASE, formatCurrency, fetchJson } from './common.js';

const trackForm = document.getElementById('track-form');
const trackIdInput = document.getElementById('track-id');
const orderStatusEl = document.getElementById('order-status');

init();

function init() {
  const saved = localStorage.getItem('pv-last-code');
  if (saved) {
    trackIdInput.value = saved;
    lookup(saved);
  }
  trackForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const code = trackIdInput.value.trim();
    if (!code) return;
    lookup(code);
  });
}

async function lookup(code) {
  try {
    const order = await fetchJson(`${API_BASE}/orders/track/${encodeURIComponent(code)}`);
    renderTimeline(order);
    localStorage.setItem('pv-last-code', order.code);
  } catch (error) {
    orderStatusEl.innerHTML = `<p class="muted">${error.message}</p>`;
  }
}

function renderTimeline(order) {
  const items = order.items.map((item) => `<li>${item.name} x ${item.quantity}</li>`).join('');
  const history = order.history
    .map((entry) => `<div class="item"><strong>${entry.status}</strong><p class="muted">${new Date(entry.at).toLocaleString()} · ${entry.actor}</p></div>`)
    .join('');
  orderStatusEl.innerHTML = `
    <div>
      <p><strong>Pedido:</strong> ${order.code}</p>
      <p><strong>Cliente:</strong> ${order.customer.name}</p>
      <p><strong>Productos:</strong></p>
      <ul>${items}</ul>
    </div>
    <div class="timeline">${history}</div>`;
}
