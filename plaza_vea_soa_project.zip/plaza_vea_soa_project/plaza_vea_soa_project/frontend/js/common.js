﻿export const API_BASE = 'http://localhost:3000/api';

export const FALLBACK_STORES = [
  { id: 'lima', name: 'Plaza Vea Lima Centro', code: 'PV-LIM-01' },
  { id: 'miraflores', name: 'Plaza Vea Miraflores', code: 'PV-MIR-11' },
  { id: 'sanisidro', name: 'Plaza Vea San Isidro', code: 'PV-SI-07' }
];

export const FALLBACK_PRODUCTS = [
  { id: 'prd-leche-entera', name: 'Leche Entera 1L', shortDescription: 'Leche fresca pasteurizada.', price: 4.5, image: 'assets/product-leche.svg', category: 'Lácteos' },
  { id: 'prd-pan-blanco', name: 'Pan Blanco 500g', shortDescription: 'Pan ideal para sándwich.', price: 3.2, image: 'assets/product-pan.svg', category: 'Panadería' },
  { id: 'prd-huevos-docena', name: 'Huevos (docena)', shortDescription: 'Docena de huevos frescos.', price: 6, image: 'assets/product-huevos.svg', category: 'Huevos' },
  { id: 'prd-arroz-superior', name: 'Arroz Superior 1Kg', shortDescription: 'Grano largo extra calidad.', price: 2.8, image: 'assets/product-arroz.svg', category: 'Granos' },
  { id: 'prd-queso-andino', name: 'Queso Andino 250g', shortDescription: 'Queso fresco ligeramente salado.', price: 7.3, image: 'assets/product-queso.svg', category: 'Lácteos' },
  { id: 'prd-cafe-andino', name: 'Café Andino 250g', shortDescription: 'Tostado medio con notas a cacao.', price: 18.5, image: 'assets/product-cafe.svg', category: 'Bebidas' }
];

export function formatCurrency(value) {
  return new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN' }).format(value || 0);
}

export async function fetchJson(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    const message = error.error || error.message || `Error ${res.status}`;
    throw new Error(message);
  }
  return res.json();
}

export function getFallbackProductsForStore(storeId) {
  const stock = {
    lima: { 'prd-leche-entera': 18, 'prd-pan-blanco': 24, 'prd-huevos-docena': 20, 'prd-arroz-superior': 55, 'prd-queso-andino': 12, 'prd-cafe-andino': 16 },
    miraflores: { 'prd-leche-entera': 10, 'prd-pan-blanco': 12, 'prd-huevos-docena': 14, 'prd-arroz-superior': 28, 'prd-queso-andino': 8, 'prd-cafe-andino': 9 },
    sanisidro: { 'prd-leche-entera': 9, 'prd-pan-blanco': 15, 'prd-huevos-docena': 11, 'prd-arroz-superior': 33, 'prd-queso-andino': 10, 'prd-cafe-andino': 8 }
  };
  const availability = stock[storeId] || {};
  return FALLBACK_PRODUCTS.map((product) => ({
    ...product,
    availability: { available: availability[product.id] ?? 0 }
  }));
}
