﻿import { API_BASE, formatCurrency, fetchJson } from './common.js';

const metricOrders = document.getElementById('metric-orders');
const metricRevenue = document.getElementById('metric-revenue');
const metricReady = document.getElementById('metric-ready');
const dashboardDay = document.getElementById('dashboard-day');
const dashboardStatus = document.getElementById('dashboard-status');
const dashboardStores = document.getElementById('dashboard-stores');
const dashboardOrders = document.getElementById('dashboard-orders');

init();

async function init() {
  try {
    const summary = await fetchJson(`${API_BASE}/dashboard`);
    renderMetrics(summary);
  } catch (error) {
    console.warn('Dashboard fallback', error.message);
  }
}

function renderMetrics(summary) {
  metricOrders.textContent = summary.totals.orders ?? 0;
  metricRevenue.textContent = formatCurrency(summary.totals.revenue || 0);
  metricReady.textContent = summary.totals.byStatus?.ready || 0;
  dashboardDay.textContent = `Día ${summary.day}`;
  renderStatus(summary.totals.byStatus || {});
  renderStores(summary.stores || []);
  renderOrders(summary.lastOrders || []);
}

function renderStatus(byStatus) {
  if (!Object.keys(byStatus).length) {
    dashboardStatus.innerHTML = '<li class="muted">Sin datos</li>';
    return;
  }
  const labels = {
    received: 'recibido',
    in_preparation: 'en preparación',
    ready: 'listo',
    cancelled: 'cancelado'
  };
  dashboardStatus.innerHTML = Object.entries(byStatus)
    .map(([status, count]) => `<li><span>${labels[status] || status}</span><strong>${count}</strong></li>`)
    .join('');
}

function renderStores(stores) {
  if (!stores.length) {
    dashboardStores.innerHTML = '<p class="muted">Sin tiendas.</p>';
    return;
  }
  dashboardStores.innerHTML = stores
    .map((store) => {
      const low = store.inventoryLowStock.length ? `<span class="pill warn">Stock bajo: ${store.inventoryLowStock.length}</span>` : '';
      return `<div class="store-pill"><strong>${store.name}</strong><br><span class="muted">${store.orders.total} pedidos · ${store.orders.ready} listos</span><br>${low}</div>`;
    })
    .join('');
}

function renderOrders(orders) {
  if (!orders.length) {
    dashboardOrders.innerHTML = '<li class="muted">No hay pedidos recientes.</li>';
    return;
  }
  dashboardOrders.innerHTML = orders
    .map((order) => `<li><strong>${order.code}</strong><br><span class="muted">${order.customer || 'Cliente'} · ${order.storeId}</span></li>`)
    .join('');
}
