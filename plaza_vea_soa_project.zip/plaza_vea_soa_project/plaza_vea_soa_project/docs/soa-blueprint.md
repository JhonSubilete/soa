﻿# Plano SOA · Plaza Vea

Resumen textual de la arquitectura implementada siguiendo el documento **Arquitectura Orientada al Servicio_AV_03**.

## Dominios y servicios

| Dominio | Servicio | Tipo | Responsabilidad |
| --- | --- | --- | --- |
| Catálogo | `/api/catalog` | Entidad | Mantiene el catálogo maestro, permite buscar por texto y consultar disponibilidad contextual por tienda. |
| Existencias por tienda | `/api/stores` | Entidad | Consolida las existencias físicas, controla campos `available`/`reserved` por producto y tienda, ofrece consultas puntuales. |
| Confirmar pedido | `/api/orders` (POST) | Tarea | Orquesta validación de stock, generación del código PV y creación del pedido (RF-M04/05). |
| Pedidos | `/api/orders`, `/api/orders/track/:code` | Entidad | Provee lectura/escritura del pedido, historial limpio para cliente y operador. |
| Preparación en tienda | `/api/orders/:id/picklist`, `/api/orders/:id/status` | Tarea | Gestiona el picking, controla transiciones recibid→preparación→listo o cancelado (RF-M06/07). |
| Acceso y roles | `/api/auth/login` | Utilidad | Autentica operadores mediante pin hash y tokens temporales (RNF-07). |
| Registro/Revisión | `/api/reports/*` | Utilidad | Genera métricas diarias, expone bitácora para auditoría (RNF-05, RNF-08). |

## Estados del pedido

```
received ──> in_preparation ──> ready
   │               │
   └──────────────> cancelled
```

- Cada transición registra evento en `data/events.json` y entrada en `order.history`.
- `reserveInventory` descuenta del campo `available` y suma `reserved`; `releaseInventory` y `consumeReserved` controlan devoluciones o finalizaciones.

## Contratos REST

| Método | Ruta | Entrada clave | Salida clave |
| --- | --- | --- | --- |
| `POST` | `/api/orders` | `clientRequestId`, `storeId`, `customer`, `items[]` | Pedido nuevo con `code`, `status`, `history`.|
| `GET` | `/api/orders/track/:code` | Código PV | Historial visible, items y estado actual. |
| `GET` | `/api/orders?status=...` | Header `Authorization: Operator <token>` | Pedidos por tienda para el operador logueado. |
| `PUT` | `/api/orders/:id/picklist` | Lista de `pickedQuantity` | Pedido actualizado, cambios automáticos a `in_preparation` o `ready`. |
| `PUT` | `/api/orders/:id/status` | Estado destino permitido por perfil | Pedido con nuevo estado + liberación/consumo de stock. |
| `GET` | `/api/reports/daily` | `day` opcional | Total pedidos, ingresos, conteos por estado/tienda + eventos del día. |

## Seguridad ligera

- Operadores almacenados en `data/operators.json` con `pinHash` (SHA-256) y `allowedStatuses`.
- `accessService` emite sesiones en memoria (`sessionStore`) con vigencia configurable.
- Rutas sensibles (`/api/orders`, `/api/reports`) aplican `operatorAuth` y validan permisos antes de ejecutar la acción.

## Cobertura de RNF

| RNF | Implementación |
| --- | --- |
| RNF-01 | Servicios stateless + datos en disco permiten reiniciar el backend y retomar pedidos en < 5 min. |
| RNF-02 | UI modular con lenguaje claro, botones y etiquetas amigables. |
| RNF-03 | Manejador de errores centralizado (`middleware/errorHandler.js`) responde con mensajes comprensibles y detalle opcional. |
| RNF-04 | `clientRequestId` obligatorio en `/api/orders` + caché temporal (`requestCache.js`). |
| RNF-05 | Historial en `order.history` y bitácora adicional (`data/events.json`). |
| RNF-06 | `reserveInventory` revalida stock antes de crear pedido o permitir cancelación. |
| RNF-07 | Tokens de operador, control de acciones por `allowedStatuses`. |
| RNF-08 | Cada pedido guarda quién, cuándo y qué cambió (`history` + reportes diarios). |

## Flujo resumido

1. Cliente selecciona tienda → consulta Catálogo (`/api/catalog?storeId=...`).
2. Checkout envía `POST /api/orders` → Confirmar pedido valida stock en Existencias y genera código PV.
3. Operador se autentica → lista pedidos (`GET /api/orders?status=received`).
4. Operador marca picking (`PUT /api/orders/:id/picklist`) → estado pasa a `in_preparation` y bitácora registra evento.
5. Al completar el picklist o presionar “Listo”, `PUT /api/orders/:id/status` cambia a `ready`, consume `reserved` y notifica al cliente a través del panel.
6. Reportes diarios y timeline (`/api/reports/*`) permiten revisar incidencias.
